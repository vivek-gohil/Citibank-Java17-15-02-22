package com.citibank.main;

import com.citibank.util.Calculator;
//import com.citibank.util.internal.CalculatorHelper;

public class CalculatorMain {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		System.out.println(calculator.add(9, 10));

//		CalculatorHelper helper = new CalculatorHelper();
//		helper.add(9, 10);
	}
}
