package com.citibank.main;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.citibank.pojo.Product;
import com.citibank.util.JSONUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;

public class ProductHTTPClientMain {

	private static final String serviceURL = "http://localhost:8081/product/controller/";
	private static final HttpClient client = HttpClient.newBuilder().version(Version.HTTP_2).build();

	public static void main(String[] args) {
		try {
			getAllProducts();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void getAllProducts()
			throws JsonMappingException, JsonProcessingException, InterruptedException, ExecutionException {
		HttpRequest request = HttpRequest.newBuilder(URI.create(serviceURL + "getDetails")).GET().build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(request, BodyHandlers.ofString());
		List<Product> products = JSONUtils.convertFromJsonTOList(response.get().body(),
				new TypeReference<List<Product>>() {
				});
		products.forEach(System.out::println);
	}
}
