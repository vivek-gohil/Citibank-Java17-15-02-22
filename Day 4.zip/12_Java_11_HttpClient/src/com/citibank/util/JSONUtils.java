package com.citibank.util;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONUtils {

	// Convert JSON into List
	public static <T> List<T> convertFromJsonTOList(String json, TypeReference<List<T>> var)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, var);
	}

	// Convert Object into JSON
	public static String convertFromObjectToJSON(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(object);
	}

	// Convert JSON into Object
	public static <T> T convertFromJSONToObject(String json, Class<T> var)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, var);
	}

}
