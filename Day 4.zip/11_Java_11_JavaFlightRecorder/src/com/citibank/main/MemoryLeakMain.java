package com.citibank.main;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class MemoryLeakMain {
	private static BlockingQueue<byte[]> queue = new LinkedBlockingDeque<byte[]>();

	public static void main(String[] args) {
		Runnable producer = () -> {
			while (true) {
				// adding 1 mb of data
				queue.offer(new byte[1 * 1024 * 1024]);
				try {
					Thread.sleep(10);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		};
		Runnable consumer = () -> {
			while (true) {
				// adding 1 mb of data
				try {
					queue.take();
					Thread.sleep(100);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		};

		new Thread(producer, "Producer Thread").start();
		new Thread(consumer, "Consumer Thread").start();

	}

}
