package com.citibank.util.internal;

public class CalculatorHelper {
	public int add(int i, int j) {
		return i + j;
	}
}
