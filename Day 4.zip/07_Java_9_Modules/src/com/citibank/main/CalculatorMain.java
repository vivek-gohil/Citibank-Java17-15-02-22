package com.citibank.main;

import com.citibank.util.Calculator;
import com.citibank.util.internal.CalculatorHelper;

//Modules
//client
public class CalculatorMain {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		int result = calculator.add(10, 20);
		System.out.println("Addition is :: " + result);

		CalculatorHelper calculatorHelper = new CalculatorHelper();
		calculatorHelper.add(10, 20);
	}
}
