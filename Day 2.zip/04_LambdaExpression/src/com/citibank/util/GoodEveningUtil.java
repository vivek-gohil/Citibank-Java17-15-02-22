package com.citibank.util;

import com.citibank.interfaces.Greet;

public class GoodEveningUtil implements Greet {
	@Override
	public void doGreet() {
		System.out.println("Good Evening");
	}
}
