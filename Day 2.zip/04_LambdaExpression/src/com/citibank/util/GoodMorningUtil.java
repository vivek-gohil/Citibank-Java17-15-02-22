package com.citibank.util;

import com.citibank.interfaces.Greet;

public class GoodMorningUtil implements Greet {
	@Override
	public void doGreet() {
		System.out.println("Good Morning");
	}
}
