package com.citibank.interfaces;

@FunctionalInterface
public interface Calculations {
	public double doCalculations(double number1, double number2);
}
