package com.citibank.interfaces;

@FunctionalInterface
public interface Greet {
	public void doGreet();
}
