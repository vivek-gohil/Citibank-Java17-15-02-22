package com.citibank.main;

import com.citibank.interfaces.Greet;
import com.citibank.util.GoodEveningUtil;
import com.citibank.util.GoodMorningUtil;

public class GeetingMain {
	public static void main(String[] args) {
		GoodMorningUtil morningUtil = new GoodMorningUtil();
		morningUtil.doGreet();

		System.out.println("-".repeat(20));

		Greet greet = new GoodEveningUtil();
		greet.doGreet();

		System.out.println("-".repeat(20));
		System.out.println("Using Lambda");
		Greet lambdaGreetGoodAfternoon = () -> System.out.println("Good Afternoon");
		lambdaGreetGoodAfternoon.doGreet();

		System.out.println("-".repeat(20));

		Greet lambdaGreetGoodEvening = () -> System.out.println("Good Evening");
		lambdaGreetGoodEvening.doGreet();

		System.out.println("-".repeat(20));

		Greet lambdaGreetGoodMonring = () -> System.out.println("Good Morning");
		lambdaGreetGoodMonring.doGreet();
	}
}
