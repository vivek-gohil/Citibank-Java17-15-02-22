package com.citibank.main;

import com.citibank.interfaces.Calculations;

public class CalculaitonMain {
	public static void main(String[] args) {
//		Calculations addition = (double number1, double number2) -> {
//			return number1 + number2;
//		};

//		Calculations addition = (x, y) -> x + y;
//
//		double result = addition.doCalculations(10, 20.90);
//		System.out.println("Addition is :: " + result);

		MyCalculations obj = new MyCalculations();
		CalculaitonMain.printResult(obj);

		System.out.println("-".repeat(50));

		Calculations addition = (x, y) -> x + y;
		// CalculaitonMain.printResult(addition);
		CalculaitonMain.printResult((x, y) -> x + y);

		System.out.println("-".repeat(50));
		CalculaitonMain.printResult((x, y) -> x - y);

		System.out.println("-".repeat(50));
		CalculaitonMain.printResult((x, y) -> x * y);

		System.out.println("-".repeat(50));
		CalculaitonMain.printResult((x, y) -> x / y);
		
		Runnable threadOne = () -> System.out.println("We are in thread");
		new Thread(threadOne).start();
		
		new Thread(() -> System.out.println("We are in thread")).start();

	}

	public static void printResult(Calculations calculations) {
		System.out.println("Result is :: " + calculations.doCalculations(10, 20));
	}
}

class MyCalculations implements Calculations {
	@Override
	public double doCalculations(double number1, double number2) {
		return number1 + number2;
	}
}
