package com.citibank.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.citibank.pojo.Person;

public class PersonMain {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 32),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));
		System.out.println(people);

		System.out.println("");
		// Code without lambda Exprssion
		// 1. Sort the list by last name
		Collections.sort(people, new Comparator<Person>() {
			@Override
			public int compare(Person p1, Person p2) {
				return p1.getLastName().compareTo(p2.getLastName());
			}
		});

		// 2. Create a method that print all the elements of list people
		System.out.println("Printing All");
		PersonMain.printAll(people);

		// 3. Create a method that print all the people that have last name beginning
		// with G
		System.out.println();
		System.out.println("Pring all last name beginning with G");
		// PersonMain.printLastNameBeginningWithG(people);
		PersonMain.printConditionally(people, new Condition() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().startsWith("G"))
					return true;
				return false;
			}
		});

		// 4. Create a method that print all the
		// peiple that have last name ending with l
		System.out.println();
		System.out.println("Pring all last name ending with L");
		// PersonMain.printLastNameEndingWithL(people);
		PersonMain.printConditionally(people, new Condition() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().endsWith("l"))
					return true;
				return false;
			}
		});
	}

	public static void printConditionally(List<Person> people, Condition condition) {
		for (Person person : people) {
			if (condition.test(person)) {
				System.out.println(person);
			}
		}
	}

	public static void printAll(List<Person> people) {
		for (Person person : people) {
			System.out.println(person);
		}
	}
}

interface Condition {
	boolean test(Person person);
}
