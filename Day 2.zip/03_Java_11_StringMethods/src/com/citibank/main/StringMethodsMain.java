package com.citibank.main;

import java.util.List;
import java.util.stream.Collectors;

public class StringMethodsMain {
	public static void main(String[] args) {
		System.out.println("1. isBlank");
		String name = "Citibank NA";
		System.out.println("Checking if value of name variable is blank :: " + name.isBlank());
		name = " ";
		System.out.println("Checking if value of name variable is blank :: " + name.isBlank());

		System.out.println("isBlank vs isEmpty");
		name = "Citibank NA";
		System.out.println("Checking if value of name variable is blank :: " + name.isEmpty());
		name = " ";
		System.out.println("Checking if value of name variable is blank :: " + name.isEmpty());

//		name = null;
//		System.out.println("Checking if value of name variable is blank :: " + name.isBlank());
		// lines() return the stream and we can use lambda expression to process data.
		System.out.println();
		System.out.println("2. lines");
		String str = "Vivek\nAnand\nBhargavi\nHimanshu";
		System.out.println(str);
		List<String> names = str.lines().collect(Collectors.toList());
		System.out.println(names);

		System.out.println();
		System.out.println("3. strip");
		str = " Citibank NA ";
		System.out.println("Value of string before calling strip");
		System.out.print("start");
		System.out.print(str);
		System.out.print("end");

		System.out.println();
		System.out.println("Value of String afer calling strip");
		System.out.print("start");
		System.out.print(str.strip());
		System.out.print("end");

		System.out.println();
		System.out.println("Value of String afer calling trim");
		System.out.print("start");
		System.out.print(str.trim());
		System.out.print("end");

		//strip() :: is Unicode-aware - remove the unicodes 
		//trim() :: removed only space (<00<20)
		System.out.println();
		str = "Citibank NA\u205F";
		System.out.println(str);
		System.out.println("Using trim = " + str.trim());
		System.out.println("Using strip = " + str.strip());
		
		System.out.println();
		System.out.println("4. repeat");
		str = " Citbank NA ";
		System.out.println(str.repeat(5));
		

	}
}





