package com.citibank.main;

public class SwitchCasePatternMatching {

	public String patternMatchingSwitch(Object object) {

		return switch (object) {
		case Integer i -> "Its an Integer";
		case String s -> "Its a String";
		case Employee e -> "It is a Employee";
		default -> "Unknown datatype";
		};
	}

	public String guardedPatternSwitch(Object object) {

		return switch (object) {
		case Integer i -> "Its an Integer";
		case String s -> "Its a String";
		case Employee e && e.getDepartment().equals("IT") -> "It is a IT Employee";
		case null -> "No object was defined";
		default -> "Unknown datatype";
		};
	}

	public static void main(String[] args) {
		String message = new SwitchCasePatternMatching().patternMatchingSwitch(new String("Hi"));
		System.out.println(message);
		System.out.println("------------------");
		message = new SwitchCasePatternMatching().patternMatchingSwitch(Integer.valueOf(10));
		System.out.println(message);
		System.out.println("------------------");
		message = new SwitchCasePatternMatching().guardedPatternSwitch(new Employee(101, "Test", "IT", 1000));
		System.out.println(message);
		System.out.println("------------------");
		message = new SwitchCasePatternMatching().guardedPatternSwitch(null);
		System.out.println(message);
	}

}
