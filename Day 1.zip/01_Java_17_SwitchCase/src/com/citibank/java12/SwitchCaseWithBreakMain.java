package com.citibank.java12;

//JDK 12
public class SwitchCaseWithBreakMain {
	public String returnUsingBreak() {
		String day = "Tuesday";
//		return switch (day) {
//		case "Monday":
//			break "Weekday";
//		default:
//			break;
//		}
		return "";
	}

	public static void main(String[] args) {

	}
}
