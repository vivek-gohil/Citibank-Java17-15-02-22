package com.citibank.java12;

public class SwitchCaseLambdaMain {
	static enum DAYS {
		MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, STAURDAY, SUNDAY
	}

	public String returnStringFromEnumUsingLambda(DAYS day) {
		return switch (day) {
		case MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY -> "Weekday";
		case STAURDAY, SUNDAY -> "Weekend";
		default -> "Unknown";
		};
	}

	public String returnStringUsingLambda(String day) {
		return switch (day) {
		case "Monday" -> "Weekday";
		case "Tuesday" -> "Weekday";
		case "Wednesday" -> "Weekday";
		case "Thursday" -> "Weekday";
		case "Firday" -> "Weekday";
		case "Saturday" -> "Weekend";
		case "Sunday" -> "Weekend";
		default -> "Unknown";
		};
	}

	public String returnStringWithMultipleCases(String day) {
		return switch (day) {
		case "Monday", "Tuesday", "Wednesday", "Thursday", "Firday" -> "Weekday";
		case "Saturday", "Sunday" -> "Weekend";
		default -> "Unknown";
		};
	}

	public static void main(String[] args) {
		String day = new SwitchCaseLambdaMain().returnStringWithMultipleCases("Tuesday");
		System.out.println(day);
		System.out.println("-----------------------");
		day = new SwitchCaseLambdaMain().returnStringFromEnumUsingLambda(DAYS.TUESDAY);
		System.out.println(day);
	}
}
