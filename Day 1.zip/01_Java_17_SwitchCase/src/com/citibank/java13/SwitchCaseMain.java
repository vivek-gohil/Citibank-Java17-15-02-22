package com.citibank.java13;

//In JDK 13 the below features are released as preview feature.
//In JDK 14 these features are made permanent.
public class SwitchCaseMain {

	public String returnUsingSwitch(String day) {

		String test = switch (day) {
		case "Monday": {
			yield "Weekday";
		}
		case "Tuesday":
			yield "Weekday";
		case "Wednesdy":
			yield "Weekday";
		default:
			yield "Unknown";
		};

		return test;
	}

	public static void main(String[] args) {
		String day = new SwitchCaseMain().returnUsingSwitch("Monday");
		System.out.println(day);
	}
}
