package com.citibank.java17;

public class SwitchCasePatternMatching {
	public String patternMatchingSwithc(Object object) {
		return switch (object) {
		case Integer i -> "It is an Integer";
		case String s -> "It is an String";
		default -> "unknown datatype";
		};
	}
}
