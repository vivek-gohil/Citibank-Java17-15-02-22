package com.citibank.main;

import java.util.Arrays;
import java.util.OptionalInt;
import java.util.function.IntBinaryOperator;

public class StreamsReduceMain {
	public static void main(String[] args) {
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		// Sum of all numbers
		int sum = 0;
		for (int i : numbers) {
			sum += i;
		}
		System.out.println(sum);

		System.out.println();

		System.out.println("Result :: " + Arrays.stream(numbers).reduce(new IntBinaryOperator() {
			@Override
			public int applyAsInt(int left, int right) {
				System.out.println("Left :: " + left + " Right :: " + right);
				return left + right;
			}
		}));

		System.out.println();

		OptionalInt optionSum = Arrays.stream(numbers).reduce((num1, num2) -> num1 + num2);

		System.out.println("Result :: " + optionSum.getAsInt());
	}
}
