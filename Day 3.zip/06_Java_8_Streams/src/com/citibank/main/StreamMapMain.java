package com.citibank.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.citibank.pojo.Person;

public class StreamMapMain {
	public static void main(String[] args) {
		List<String> alphabets = Arrays.asList("a", "b", "c", "d", "e");

		// Convert this alphabets to upper case and add it into new list
		// Java 7 approach
		List<String> alphabetsUpper = new ArrayList<String>();
		for (String string : alphabets) {
			alphabetsUpper.add(string.toUpperCase());
		}

		for (String string : alphabetsUpper) {
			System.out.println(string);
		}

		System.out.println("-".repeat(50));
		// Java 8 Using Streams
		alphabets.stream().map(new Function<String, String>() {
			@Override
			public String apply(String alphabet) {
				return alphabet.toUpperCase();
			}
		}).forEach(new Consumer<String>() {
			@Override
			public void accept(String alphabetUpper) {
				System.out.println(alphabetUpper);
			}
		});

		System.out.println("-".repeat(50));
		// Java 8 Lambda - Printing - forEach
		alphabets.stream().map(alphabet -> alphabet.toUpperCase())
				.forEach(alphabetUpper -> System.out.println(alphabetUpper));

		// Java 8 Streams and Lambda - Collect
		alphabetsUpper = alphabets.stream().map(alphabet -> alphabet.toUpperCase()).collect(Collectors.toList());

		alphabetsUpper.forEach(alphabet -> System.out.println(alphabet));

		System.out.println("-".repeat(50));

		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 32),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		// Print all the first name in upper case and store in new list
		List<String> firstNameList = people.stream().map(person -> person.getFirstName().toUpperCase())
				.collect(Collectors.toList());

		List<Person> newPersonList = people.stream().map(person -> {
			Person personUpperCase = new Person();
			personUpperCase.setFirstName(person.getFirstName().toUpperCase());

			return personUpperCase;
		}).collect(Collectors.toList());

		System.out.println("-".repeat(50));
		newPersonList.forEach(person -> System.out.println(person));

		System.out.println("-".repeat(50));
		people.forEach(person -> System.out.println(person.getFirstName()));
		System.out.println("-".repeat(50));
		people.forEach(System.out::println);

	}
}
