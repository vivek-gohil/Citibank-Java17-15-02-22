package com.citibank.main;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StreamsFilterMain {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Vivek", "Bahubali", "Trupti", "Samarth");

		// Sort the names and store in new list
		List<String> sortedNames = names.stream().sorted().collect(Collectors.toList());
		sortedNames.forEach(System.out::println);

		System.out.println();

		List<String> sortedNames2 = names.stream().sorted((name1, name2) -> name2.compareTo(name1)).toList();
		sortedNames2.forEach(System.out::println);

		System.out.println("In ReversOrder");
		System.out.println();

		sortedNames2 = names.stream().sorted(Comparator.reverseOrder()).toList();
		sortedNames2.forEach(System.out::println);

		StreamsFilterMain streamsFilterMain = new StreamsFilterMain();
		// Print all accept Bahubali
		// Java 7
		for (String name : names) {
			if (!name.equals("Bahubali")) {
				System.out.println(name);
			}
		}

		System.out.println();
		Predicate<String> condition = name -> !name.equals("Trupti");
		names.stream().filter(condition).forEach(name -> System.out.println(name));

		System.out.println();

		names.stream().filter(name -> !name.equals("Trupti")).forEach(name -> System.out.println(name));

		System.out.println();

		names.stream().filter(name -> streamsFilterMain.isNotBahubali(name)).forEach(name -> System.out.println(name));

		System.out.println();

		// Method Refrencing in Java 8
//		names.stream().filter(StreamsFilterMain::isNotBahubali).forEach(name -> System.out.println(name));
//
//		names.stream().filter(StreamsFilterMain::isNotBahubali).forEach(System.out::println);

		names.stream().filter(streamsFilterMain::isNotBahubali).forEach(System.out::println);

	}

	private boolean isNotBahubali(String name) {
		return !name.equals("Bahubali");
	}
}
