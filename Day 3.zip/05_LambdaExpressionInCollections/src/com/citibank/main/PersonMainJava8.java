package com.citibank.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.citibank.pojo.Person;

public class PersonMainJava8 {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 32),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));
		System.out.println(people);

		// 1. Sort the list by last name
		Comparator<Person> compareByLastName = (p1, p2) -> p1.getLastName().compareTo(p2.getLastName());
		Collections.sort(people, compareByLastName);

		System.out.println("-".repeat(50));

		// 2. Print all elements of list
		Consumer<Person> printPersonDetails = (p) -> System.out.println(p);
		// people.forEach(printPersonDetails);
		people.forEach(p -> System.out.println(p));
		System.out.println("-".repeat(50));
		people.forEach(p -> System.out.println(p.getFirstName()));

		System.out.println("-".repeat(50));
		Predicate<Person> lastNameStartsWithG = (p) -> p.getLastName().startsWith("G");
		Consumer<Person> printAll = p -> System.out.println(p);
		PersonMainJava8.printConditionally(people, lastNameStartsWithG, printAll);
		
		System.out.println("-".repeat(50));
		
		Consumer<Person> printFirstNameAge = p -> System.out.println(p.getFirstName() + " " + p.getAge());
		PersonMainJava8.printConditionally(people, lastNameStartsWithG, printFirstNameAge);
	}

	public static void printConditionally(List<Person> people, Predicate<Person> predicate, Consumer<Person> consumer) {
		for (Person person : people) {
			if (predicate.test(person)) {
				consumer.accept(person);
				// System.out.println(person);
			}
		}
	}
}
